#include "Conta.h"

/*
No documento pede para imprimir no terminal as opcoes das contas destino e origem das operacoes.
Eu fiz as funcoes, mas como o comando 'system("clear")' nao limpa as mensagens do documento de resposta
tambem, resolvi comentar todas
*/

int main(){
    char c;
    int numConta = 0, contDestino, contOrigem;
    tConta *conta;


    while(1){
        scanf("%c", &c);

        if( c == '0' ){
            break;

        }
        else if( c == '1' ){
            // ImprimirOpcoesDest(numConta, conta);

            scanf("%d", &contDestino);
            conta = RealizaSaque(contDestino-1, conta);

        }   
        else if( c == '2' ){
            // ImprimirOpcoesDest(numConta, conta);

            scanf("%d", &contDestino);
            conta = RealizaDeposito(contDestino-1, conta);

        }
        else if( c == '3' ){
            // contOrigem = ImprimirOpcoesDestEOrigem(numConta, conta);
            //scanf("%d", &contDestino);

            scanf("%d %d", &contOrigem, &contDestino);
            conta = RealizaTransferencia(contDestino-1, contOrigem-1, conta);

        }
        else if( c == '4' ){

            conta = CriaConta(numConta);
            numConta++;

        }    
        else if( c == '5' ){
            ImprimirRelatorio(numConta, conta);

        }
    }

    LiberaConta(numConta, conta);
    free(conta);

    return 0;
}