#include "Conta.h"

struct conta{
    tUsuario *usuario;
    int conta;
    float saldo;
};

tConta *CriaConta(int num){
    tConta *p;
    int cont;

    if( num == 0 ){
        p = (tConta*) malloc(sizeof(struct conta));

    } else {
        p = (tConta*) realloc( p,(num+1)*sizeof(struct conta) );
    }

    (p+num)->usuario = LeUsuario();

    scanf("%d", &cont);
    (p+num)->conta = cont;
    (p+num)->saldo = 0.0;

    // printf("\nConta criada!\n");

    return p;
}

tConta *RealizaSaque(int num, tConta *conta){
    float qtd, saldo = (conta+num)->saldo;

    scanf("%f", &qtd);

    if(qtd > saldo){
        // ImprimeInsuficiente();
        return conta;
    }

    (conta+num)->saldo -= qtd;

    //printf("\nSaque realizado!\n");

    return conta;
}

tConta *RealizaDeposito(int num, tConta *conta){
    float qtd;

    scanf("%f", &qtd);

    (conta+num)->saldo += qtd;

    //printf("\nDeposito realizado!\n");

    return conta;
}

tConta *RealizaTransferencia(int dest, int org, tConta *conta){
    float qtd, saldo = (conta+org)->saldo;

    scanf("%f", &qtd);

    if( qtd > saldo ){
        // ImprimeInsuficiente();
        return conta;
    }

    (conta+org)->saldo -= qtd;
    (conta+dest)->saldo += qtd;

    //printf("\nTransferencia realizada!\n");

    return conta;
}

void ImprimirRelatorio(int num, tConta *conta){
    int i;

    //system("clear");

    printf("===| Imprimindo Relatorio |===\n");

    for(i = 0; i < num; i++){
        ImprimeConta(conta+i);
        printf("\n");
    }
}

void ImprimeConta(tConta *conta){

    printf("Conta: %d\n", conta->conta);
    printf("Saldo: R$ %.2f\n", conta->saldo);
    ImprimeUsuario(conta->usuario);
    ImprimeCPF(conta->usuario);
}

void ImprimirOpcoesDest(int num, tConta *conta){
    int i;

    printf("Digite a Conta Destino da operacao entre as abaixo:\n");

    for( i = 0; i < num; i++ ){
        printf("%d - ", i+1);
        ImprimeUsuario((conta+i)->usuario);
    }

}

void ImprimeInsuficiente(){
    printf("\nSaldo insuficiente!\n");
}

int ImprimirOpcoesDestEOrigem(int num, tConta *conta){
    int i, org;

    printf("Digite a Conta Origem da operacao entre as abaixo:\n");

    for( i = 0; i < num; i++ ){
        printf("%d - ", i+1);
        ImprimeUsuario((conta+i)->usuario);
    }

    scanf("%d", &org);

    printf("Digite a Conta Destino da operacao entre as abaixo:\n");

    for( i = 0; i < num; i++ ){
        if(i == org-1)
            continue;

        printf("%d - ", i+1);
        ImprimeUsuario((conta+i)->usuario);
    }

    return org;
}

void LiberaConta(int num, tConta *conta){
    int i;

    for(i = 0; i < num; i++){
        free((conta+i)->usuario);
    }
}
