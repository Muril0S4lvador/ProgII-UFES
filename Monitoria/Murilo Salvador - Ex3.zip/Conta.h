#ifndef _CONTA_H_
#define _CONTA_H_

#include "Usuario.h"

typedef struct conta tConta;

tConta *CriaConta(int num);

tConta *RealizaSaque(int num, tConta *conta);

tConta *RealizaDeposito(int num, tConta *conta);

tConta *RealizaTransferencia(int dest, int org, tConta *conta);

void ImprimirRelatorio(int num, tConta *conta);

void ImprimirOpcoesDest(int num, tConta *conta);

void ImprimeConta(tConta *conta);

void ImprimeInsuficiente();

int ImprimirOpcoesDestEOrigem(int num, tConta *conta);

void LiberaConta(int num, tConta *conta);

#endif