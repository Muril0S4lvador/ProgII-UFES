#include "../headers/Extrato.h"

struct extrato{
    double valor;
};

tExtrato_pt InicializaExtrato(){
    tExtrato_pt p = calloc(1, sizeof(struct extrato));
    return p;
}

tExtrato_pt AtualizaExtrato(tExtrato_pt p, double valor, int qtd, int ordem){    

    p = realloc(p, (qtd)*sizeof(struct extrato));

    if( ordem == SAQUE ){
        valor *= (-1);
        (p+(qtd-1))->valor = valor;

    } else if( ordem == DEPOSITO ){
        (p+(qtd-1))->valor = valor;

    }

    
    return p;
}

void Extrato(tExtrato_pt extrato, int qtd, int limite, FILE *f){
    int i, j;

    for(i = qtd-1 , j = 0; i >= 0  ; i--, j++){
        if(j == limite)
            break;
        fprintf(f, "%.2lf\n", (extrato+i)->valor);
    }

}