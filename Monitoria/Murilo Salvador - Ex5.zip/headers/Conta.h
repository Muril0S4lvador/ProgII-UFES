#ifndef _CONTA_H_
#define _CONTA_H_

#include "../headers/Usuario.h"
#include "../headers/Extrato.h"

typedef struct conta tConta;

/* Ponteiro de funcao */
typedef tConta* (*ftprOperacao)(tConta*, tConta*, tConta*);

tConta *RealizaOperacao(ftprOperacao operacao ,tConta *origem, tConta *destino, tConta *conta);
/* Ponteiro de funcao (FIM)*/

tConta *CriaConta(tConta *p, int num);

tConta *Saque(tConta *origem, tConta *destino, tConta *conta);

tConta *Deposito(tConta *origem, tConta *destino, tConta *conta);

tConta *Transferencia(tConta *origem, tConta *destino, tConta *conta);

tConta* BuscaConta(int conta_int, tConta *conta, int qtd);

tConta* ImprimeERetornaOrigem(int num, tConta *conta);

tConta* BuscaDestino(int qtd, tConta *conta, tConta *origem);

tConta* AdicionaSaldoDest(tConta *destino, float valor);

tConta* SubtraiSaldo(tConta *origem, float valor);

void ImprimeOpcOrigemTransf(tConta* conta, int qtd);

void ImprimeOpcDestTransf(tConta* conta, int qtd, int num);

void ImprimirOpcoesDest(int num, tConta *conta);

void ImprimirRelatorio(int num, tConta *conta);

void ImprimirRelatorioFILE(int num, tConta *conta);

void ImprimeConta(tConta *conta);

void ImprimeContaFILE(tConta *conta, FILE *f);

void ImprimeInsuficiente();

void ImprimeExtrato(tConta *conta, int limite);

int RetornaConta(int num);

int confirmaAcao();

void LiberaConta(int num, tConta *conta);

#endif