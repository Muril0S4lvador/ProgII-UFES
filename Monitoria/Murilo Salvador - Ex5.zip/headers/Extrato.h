#ifndef _EXTRATO_H_
#define _EXTRATO_H_

#include "../headers/Usuario.h"

#define SAQUE 0
#define DEPOSITO 1
#define PASTA "mout/"

typedef struct extrato tExtrato;

typedef tExtrato* tExtrato_pt;

tExtrato_pt InicializaExtrato();

tExtrato_pt AtualizaExtrato(tExtrato_pt p, double valor, int qtd, int ordem);

void Extrato(tExtrato_pt extrato, int qtd, int limite, FILE *f);

#endif