#ifndef _USUARIO_H_
#define _USUARIO_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct usuario tUsuario;

tUsuario* LeUsuario();

void ImprimeUsuario(tUsuario *usuario);

void ImprimeCPF(tUsuario *usuario);

void ImprimeUsuarioFILE(tUsuario *usuario, FILE *f);

void ImprimeCPFFILE(tUsuario *usuario, FILE *f);

#endif