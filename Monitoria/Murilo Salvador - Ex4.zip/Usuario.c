#include "Usuario.h"

struct usuario{
    char nome[20];
    char cpf[7];
};

tUsuario* LeUsuario(){
    tUsuario *p = (tUsuario*) malloc(sizeof(struct usuario));

    scanf("%s ", p->nome);
    scanf("%s", p->cpf);
    scanf("%*c");

    return p;
}

void ImprimeUsuario(tUsuario *usuario){
    printf("Nome: %s\n", usuario->nome);

}

void ImprimeUsuarioFILE(tUsuario *usuario, FILE *f){
    fprintf(f,"Nome: %s\n", usuario->nome);

}

void ImprimeCPF(tUsuario *usuario){
    printf("CPF: %s\n", usuario->cpf);

}

void ImprimeCPFFILE(tUsuario *usuario, FILE *f){
    fprintf(f, "CPF: %s\n", usuario->cpf);

}
