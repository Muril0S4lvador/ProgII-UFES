#include "Conta.h"

/*
No documento pede para imprimir no terminal as opcoes das contas destino e origem das operacoes.
Eu fiz as funcoes, mas como o comando 'system("clear")' nao limpa as mensagens do documento de resposta
tambem, resolvi comentar todas
*/


int main(){
    char c;
    int numConta = 0, contDestino, limite;
    tConta *conta, *destino, *origem;


    while(1){
        scanf("%c", &c);

        if( c == '0' ){
            break;

        }
        else if( c == '1' ){
            /* SAQUE */

            ImprimirOpcoesDest(numConta, conta);

            scanf("%d", &contDestino);
            destino = BuscaConta(contDestino, conta, numConta);
            destino = RealizaSaque(destino, conta);

        }   
        else if( c == '2' ){
            /* DEPOSITO */

            ImprimirOpcoesDest(numConta, conta);

            scanf("%d", &contDestino);
            destino = BuscaConta(contDestino, conta, numConta);
            destino = RealizaDeposito(destino, conta);

        }
        else if( c == '3' ){
            /* TRANSFERENCIA */

            origem = ImprimeERetornaOrigem(numConta, conta);
            destino = BuscaDestino(numConta, conta, origem);
            conta = RealizaTransferencia(origem, destino, conta);

        }
        else if( c == '4' ){
            /* CRIAR CONTA */

            conta = CriaConta(numConta);
            numConta++;

        }    
        else if( c == '5' ){
            ImprimirRelatorio(numConta, conta);
            ImprimirRelatorioFILE(numConta, conta);

        }
        else if( c == '6'){
            /* EXTRATO */

            ImprimirOpcoesDest(numConta, conta);

            scanf("%d", &contDestino);
            destino = BuscaConta(contDestino, conta, numConta);
            scanf("%d", &limite);
            ImprimeExtrato(destino, limite);
        }
    }

    LiberaConta(numConta, conta);
    free(conta);

    return 0;
}