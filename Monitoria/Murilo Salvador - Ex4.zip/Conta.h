#ifndef _CONTA_H_
#define _CONTA_H_

#include "Usuario.h"
#include "Extrato.h"

typedef struct conta tConta;

tConta *CriaConta(int num);

tConta *RealizaSaque(tConta *destino, tConta *conta);

tConta *RealizaDeposito(tConta *destino, tConta *conta);

tConta *RealizaTransferencia(tConta *origem, tConta *destino, tConta *conta);

tConta* BuscaConta(int conta_int, tConta *conta, int qtd);

tConta* ImprimeERetornaOrigem(int num, tConta *conta);

tConta* BuscaDestino(int qtd, tConta *conta, tConta *origem);

tConta* AdicionaSaldoDest(tConta *destino, float valor);

tConta* SubtraiSaldo(tConta *origem, float valor);

void ImprimeOpcOrigemTransf(tConta* conta, int qtd);

void ImprimeOpcDestTransf(tConta* conta, int qtd, int num);

void ImprimirOpcoesDest(int num, tConta *conta);

void ImprimirRelatorio(int num, tConta *conta);

void ImprimirRelatorioFILE(int num, tConta *conta);

void ImprimeConta(tConta *conta);

void ImprimeContaFILE(tConta *conta, FILE *f);

void ImprimeInsuficiente();

void ImprimeExtrato(tConta *conta, int limite);

int RetornaConta(int num);

void LiberaConta(int num, tConta *conta);

#endif