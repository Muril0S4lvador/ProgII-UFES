#include "Conta.h"

struct conta{
    tUsuario *usuario;
    int conta;
    float saldo;
    tExtrato_pt extrato;
    int numOperacoes;
};


tConta *CriaConta(int num){
    tConta *p;
    int cont;

    if( num == 0 ){
        p = (tConta*) malloc(sizeof(struct conta));

    } else {
        p = (tConta*) realloc( p,(num+1)*sizeof(struct conta) );
    }

    (p+num)->usuario = LeUsuario();

    scanf("%d", &cont);
    (p+num)->conta = cont;
    (p+num)->saldo = 0.0;

    (p+num)->extrato = InicializaExtrato();
    (p+num)->numOperacoes = 0.0;

    printf("\nConta criada!\n");

    return p;
}

tConta *RealizaSaque(tConta *destino, tConta *conta){
    float valor, saldo = destino->saldo;

    scanf("%f", &valor);

    if(valor > saldo){
        ImprimeInsuficiente();
        return destino;
    }

    destino = SubtraiSaldo(destino, valor);

    destino->numOperacoes++;
    destino->extrato = AtualizaExtrato(destino->extrato, valor, destino->numOperacoes, SAQUE);

    printf("\nSaque realizado!\n");

    return destino;
}

tConta *RealizaDeposito(tConta *destino, tConta *conta){
    float valor;

    scanf("%f", &valor);

    destino = AdicionaSaldoDest(destino, valor);

    destino->numOperacoes++;
    destino->extrato = AtualizaExtrato(destino->extrato, valor, destino->numOperacoes, DEPOSITO);

    printf("\nDeposito realizado!\n");

    return destino;
}

tConta *RealizaTransferencia(tConta *origem, tConta *destino, tConta *conta){
    float valor, saldo = origem->saldo;

    scanf("%f", &valor);

    if( valor > saldo ){
        ImprimeInsuficiente();
        return conta;
    }

    destino = AdicionaSaldoDest(destino, valor);
    origem = SubtraiSaldo(origem, valor);

    destino->numOperacoes++;
    destino->extrato = AtualizaExtrato(destino->extrato, valor, destino->numOperacoes, DEPOSITO);

    origem->numOperacoes++;
    origem->extrato = AtualizaExtrato(origem->extrato, valor, origem->numOperacoes , SAQUE);

    printf("\nTransferencia realizada!\n");

    return conta;
}

tConta* BuscaConta(int conta_int, tConta *conta, int qtd){
    int i;
    for(i = 0; i < qtd; i++){
        if((conta+i)->conta == conta_int)
            return conta+i;
    }
}

tConta* ImprimeERetornaOrigem(int qtd, tConta *conta){
    int conta_int;

    ImprimeOpcOrigemTransf(conta, qtd);

    scanf("%d", &conta_int);
    tConta *origem = BuscaConta(conta_int, conta, qtd);

    return origem;
}

tConta* BuscaDestino(int qtd, tConta *conta, tConta *origem){
    int conta_int, num = origem->conta;

    ImprimeOpcDestTransf(conta, qtd, num);

    scanf("%d", &conta_int);
    tConta *dest = BuscaConta(conta_int, conta, qtd);

    return dest;
}

tConta* AdicionaSaldoDest(tConta *destino, float valor){
    destino->saldo += valor;

    return destino;
}

tConta* SubtraiSaldo(tConta *origem, float valor){
    origem->saldo -= valor;

    return origem;
}

void ImprimeOpcOrigemTransf(tConta* conta, int qtd){
    int i;

    printf("\nDigite a Conta Origem da operacao entre as abaixo:\n");

    for( i = 0; i < qtd; i++ ){
        printf("%d - ", (conta+i)->conta);
        ImprimeUsuario((conta+i)->usuario);
    }
}

void ImprimeOpcDestTransf(tConta* conta, int qtd, int num){
    int i;

    printf("\nDigite a Conta Destino da operacao entre as abaixo:\n");

    for( i = 0; i < qtd; i++ ){
        if((conta+i)->conta == num){
            continue;

        } else {
            printf("%d - ", (conta+i)->conta);
            ImprimeUsuario((conta+i)->usuario);

        }
    }
}

void ImprimirOpcoesDest(int num, tConta *conta){
    int i;

    printf("\nDigite a Conta Destino da operacao entre as abaixo:\n");

    for( i = 0; i < num; i++ ){
        printf("%d - ", (conta+i)->conta);
        ImprimeUsuario((conta+i)->usuario);
    }

}

void ImprimirRelatorio(int num, tConta *conta){
    int i;

    printf("===| Imprimindo Relatorio |===\n");

    for(i = 0; i < num; i++){
        ImprimeConta(conta+i);
        printf("\n");
    }
}

void ImprimirRelatorioFILE(int num, tConta *conta){
    int i;
    FILE *f;
    char endereco[25] = "mout/relatorio.txt";
    f = fopen(endereco, "w");

    fprintf(f, "===| Imprimindo Relatorio |===\n");


    for(i = 0; i < num; i++){
        ImprimeContaFILE(conta+i, f);
        fprintf(f, "\n");
    }

    fclose(f);
}

void ImprimeConta(tConta *conta){

    printf("Conta: %d\n", conta->conta);
    printf("Saldo: R$ %.2f\n", conta->saldo);
    ImprimeUsuario(conta->usuario);
    ImprimeCPF(conta->usuario);

}

void ImprimeContaFILE(tConta *conta, FILE *f){

    fprintf(f, "Conta: %d\n", conta->conta);
    fprintf(f, "Saldo: R$ %.2f\n", conta->saldo);
    ImprimeUsuarioFILE(conta->usuario, f);
    ImprimeCPFFILE(conta->usuario, f);

}

void ImprimeInsuficiente(){
    printf("\nSaldo insuficiente!\n");
}

void ImprimeExtrato(tConta *conta, int limite){
    FILE *f;
    char endereco[13] = PASTA, num[4];
    sprintf(num, "%d", conta->conta);
    strcat(endereco, num);
    strcat(endereco, ".txt");

    f = fopen(endereco, "wt");

    fprintf(f, "===| Imprimindo Extrato |===\n");

    ImprimeContaFILE(conta, f);

    fprintf(f, "\nUltimas %d transações\n", limite);

    Extrato(conta->extrato, conta->numOperacoes, limite, f);

    fclose(f);

}

int RetornaConta(int num){
    return num;
}

void LiberaConta(int num, tConta *conta){
    int i;

    for(i = 0; i < num; i++){
        free((conta+i)->extrato);
    }

    for(i = 0; i < num; i++){
        free((conta+i)->usuario);
    }
}
