#include "Aluno.h"
#include <stdio.h>

tAluno LeAluno(){
    tAluno aluno;

    scanf("%s%*c", &aluno.nome);
    scanf("%d%*c", &aluno.matricula);
    scanf("%d %d %d%*c", &aluno.n1, &aluno.n2, &aluno.n3);

    aluno = DefineAprovadoOuNao(aluno);

    return aluno;
}

tAluno DefineAprovadoOuNao(tAluno aluno){
    float media;

    media = (aluno.n1 + aluno.n2 + aluno.n3)/3.0;

    if( media >= 7.0 ) aluno.aprovado = 1;
    else aluno.aprovado = 0;

    return aluno;
}

void OrdenaAlunos(tAluno aluno[], int qtd){
    tAluno aux;
    int i, j;

    for( i = 0; i < qtd-1 ;i++ ){
        for( j = i+1; j < qtd; j++ ){
            if(aluno[i].matricula > aluno[j].matricula){
                aux = aluno[i];
                aluno[i] = aluno[j];
                aluno[j] = aux;
            }
        }
    }


}

void ImprimeAlunosAprovados(tAluno aluno){
    if( aluno.aprovado ){
        printf("%s\n", aluno.nome);

    }
}
