#ifndef _ALUNO_H_
#define _ALUNO_H_
#define QTD 3

typedef struct{
    char nome[25];
    int matricula;
    int n1, n2, n3;
    int aprovado;
} tAluno;

tAluno LeAluno();
tAluno DefineAprovadoOuNao(tAluno aluno);
void OrdenaAlunos(tAluno aluno[], int qtd);
void ImprimeAlunosAprovados(tAluno aluno);

#endif