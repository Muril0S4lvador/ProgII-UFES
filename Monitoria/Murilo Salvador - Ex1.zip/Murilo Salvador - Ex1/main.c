#include "Aluno.h"
#include <stdio.h>

int main(){
    int i, qtd;

    scanf("%d", &qtd);
    tAluno alunos[qtd];

    for(i = 0; i < qtd; i++){
        alunos[i] = LeAluno();

    }

    OrdenaAlunos(alunos, qtd);

    printf("Alunos Aprovados:\n");
    for(i = 0; i < qtd; i++){
        ImprimeAlunosAprovados(alunos[i]);

    }

    return 0;
}