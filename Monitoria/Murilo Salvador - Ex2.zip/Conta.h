#ifndef _CONTA_H_
#define _CONTA_H_

#include "Usuario.h"

typedef struct conta tConta;

tConta *CriaConta();

tConta *RealizaSaque(tConta *conta);

tConta *RealizaDeposito(tConta *conta);

void ImprimeConta(tConta *conta);

void ImprimeSaque(float valor);

void ImprimeDeposito(float valor);

void ImprimeInsuficiente();

void ImprimeSaldo(tConta *conta);

void LiberaConta(tConta* conta);

#endif