#include "Conta.h"

int main(){
    char c;
    tConta *conta;

    conta = CriaConta();

    while(1){
        scanf("%c", &c);

        if( c == '0' )
            break;

        else if( c == '1' )
            conta = RealizaSaque(conta);
            
        else if( c == '2' )
            conta = RealizaDeposito(conta);
        
    }
    ImprimeSaldo(conta);

    LiberaConta(conta);
    free(conta);

    return 0;
}