#include "Conta.h"

struct conta{
    tUsuario *usuario;
    int conta;
    int agencia;
    float saldo;
};

tConta *CriaConta(){
    tConta *p = (tConta*) malloc(sizeof(struct conta));

    p->usuario = LeUsuario();
    p->conta = 12345;
    p->agencia = 1234;
    p->saldo = 0.0;

    ImprimeConta(p);

    return p;
}

tConta *RealizaSaque(tConta *conta){
    float qtd, saldo = conta->saldo;

    scanf("%f", &qtd);

    if(qtd > saldo){
        ImprimeInsuficiente();
        return conta;
    }

    conta->saldo -= qtd;

    ImprimeSaque(qtd);

    return conta;
}

tConta *RealizaDeposito(tConta *conta){
    float qtd;

    scanf("%f", &qtd);

    (conta->saldo) += qtd;

    ImprimeDeposito(qtd);

    return conta;
}

void ImprimeConta(tConta *conta){

    ImprimeNome(conta->usuario);
    printf("Conta: %d\n", conta->conta);
    printf("Agência: %d\n", conta->agencia);

}

void ImprimeSaque(float valor){
    printf("\nSaque realizado no valor de %.2f\n", valor);
}

void ImprimeDeposito(float valor){
    printf("\nDeposito realizado no valor de %.2f\n", valor);
}

void ImprimeInsuficiente(){
    printf("\nSaldo insuficiente!\n");
}

void ImprimeSaldo(tConta *conta){
    printf("\nSaldo: %.2f\n", conta->saldo);
}

void LiberaConta(tConta* conta){
    free(conta->usuario);
}
