#include "Usuario.h"

struct usuario{
    char nome[20];
    char cpf[7];
};

tUsuario* LeUsuario(){
    tUsuario *p = (tUsuario*) malloc(sizeof(struct usuario));

    scanf("%s ", p->nome);
    scanf("%s", p->cpf);
    scanf("%*c");

    return p;
}

void ImprimeNome(tUsuario *usuario){
    printf("Usuário: %s\n", usuario->nome);
}
