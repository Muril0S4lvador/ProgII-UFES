#ifndef _USUARIO_H_
#define _USUARIO_H_

#include <stdio.h>
#include <stdlib.h>

typedef struct usuario tUsuario;

tUsuario* LeUsuario();

void ImprimeNome(tUsuario *usuario);

#endif