#include "triangulo.h"
#include <stdio.h>
#define MULTAT 0.7

tTriangulo LeTriangulo() {
  tTriangulo tri;

  scanf("%d %d%*c", &tri.base, &tri.altura);

  return tri;
}

void CalculaEImprimeMultaTri(tTriangulo tri) {
  int AreaT;
  float multa;

  AreaT = (tri.base * tri.altura) / 2;
  multa = AreaT * MULTAT;

  printf("Preco: %.2f\n", multa);
  }