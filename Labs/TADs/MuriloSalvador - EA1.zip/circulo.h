#ifndef _CIRCULO_H_
#define _CIRCULO_H_

typedef struct {
  int raio;
} tCirculo;

tCirculo LeCirculo();
void CalculaEImprimeMultaCirculo(tCirculo c);

#endif