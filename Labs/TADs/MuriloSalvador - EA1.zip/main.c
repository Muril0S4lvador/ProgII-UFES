#include <stdio.h>
#include "circulo.h"
#include "retangulo.h"
#include "triangulo.h"

int main(void) {
  int qtd, i;
  char c;

  scanf("%d", &qtd);

  for(i=0; i<=qtd; i++){
    scanf("%c", &c);
    
    if( c == 'C' ){
      tCirculo c = LeCirculo();
      CalculaEImprimeMultaCirculo( c );
      
    } else if( c == 'R' ){
      tRetangulo ret = LeRetangulo();
      CalculaEImprimeMultaRet( ret );
      
    } else if( c == 'T' ){
      tTriangulo tri = LeTriangulo();
      CalculaEImprimeMultaTri( tri );
      
    }
  }
  
  return 0;
}