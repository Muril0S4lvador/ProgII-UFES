#ifndef _RETANGULO_H_
#define _RETANGULO_H_

typedef struct {
  int comprimento;
  int largura;
} tRetangulo;

tRetangulo LeRetangulo();
void CalculaEImprimeMultaRet(tRetangulo ret);

#endif