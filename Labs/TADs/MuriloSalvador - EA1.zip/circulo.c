#include "circulo.h"
#include <math.h>
#include <stdio.h>
#define PI 3.1415
#define MULTAC 0.6

tCirculo LeCirculo() {
  tCirculo c;

  scanf("%d%*c", &c.raio);

  return c;
}

void CalculaEImprimeMultaCirculo(tCirculo c) {
  int areaC;
  float multa;

  areaC = pow(c.raio, 2) * PI;
  multa = areaC * MULTAC;

  printf("Preco: %.2f\n", multa);
}