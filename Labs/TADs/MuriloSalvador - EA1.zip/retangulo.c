#include "retangulo.h"
#include <stdio.h>
#define MULTARET 0.8

tRetangulo LeRetangulo() {
  tRetangulo ret;

  scanf("%d %d%*c", &ret.comprimento, &ret.largura);

  return ret;
}

void CalculaEImprimeMultaRet(tRetangulo ret) {
  int AreaR;
  float multa;

  AreaR = ret.comprimento * ret.largura;
  multa = AreaR * MULTARET;

  printf("Preco: %.2f\n", multa);
}