#ifndef _TRIANGULO_H_
#define _TRIANGULO_H_

typedef struct {
  int base;
  int altura;
} tTriangulo;

tTriangulo LeTriangulo();
void CalculaEImprimeMultaTri(tTriangulo tri);

#endif