#include "tRetangulo.h"
#include <stdio.h>
#include <stdlib.h>

tRetangulo criaRetangulo(tPonto p1, tPonto p2){
  tRetangulo ret;
  ret.p1 = p1;
  ret.p2 = p2;

  ValidaRetangulo(p1, p2);

  return ret;
}
void ValidaRetangulo(tPonto p1, tPonto p2){
  int validx = ValidaPontoX(p1.x, p2.x),
      validy = ValidaPontoY(p1.y, p2.y);

    if( !(validx) && !(validy) ){
      printf("Retangulo Invalido!\n");
      exit(0);
    }
}

ValidaPontoX(float x1, float x2){
  if( x1 == x2 ) return 0;

  return 1;
}

ValidaPontoY(float y1, float y2){
  if( y1 == y2 ) return 0;

  return 1;
}