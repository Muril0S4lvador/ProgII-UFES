#ifndef TGEOMETRICA_H
#define TGEOMETRICA_H

#include "tPonto.h"
#include "tCirculo.h"
#include "tRetangulo.h"
#include "tTriangulo.h"

#endif