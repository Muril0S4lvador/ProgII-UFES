#ifndef TCIRCULO_H
#define TCIRCULO_H

#include "tPonto.h"

#define PI 3.141592

typedef struct{
  tPonto p;
  float raio;
}tCirculo;


tCirculo criaCirculo(tPonto p, float r);

float calcularArea(tCirculo c);

void imprimeCirculo (tCirculo c);

/**
 * A funcao confere se o raio nao eh negativo. 
 * caso for, aparece o aviso e o programa para
*/

void VerificaCirculo(tCirculo c);

static int VerificaRaio(float r);

#endif