#ifndef TPONTO_H
#define TPONTO_H
#include<stdio.h>
#include<math.h>


typedef struct {
  float x;
  float y;
}tPonto;



/**
Criar um ponto a partir de dois numeros flutuantes

@x - float maior que zero
@y - floar maior que zero

return  um tipo tPonto preenchido
*/
tPonto criaPonto(float x, float y);

float distancia (tPonto p1, tPonto p2);

void imprime (tPonto p);

#endif