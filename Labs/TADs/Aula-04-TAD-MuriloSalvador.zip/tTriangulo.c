#include "tTriangulo.h"
#include <stdlib.h>

tTriangulo criaTri(tPonto p1, tPonto p2, tPonto p3)
{
  tTriangulo tri;
  tri.p1 = p1;
  tri.p2 =p2;
  tri.p3 = p3;

  ValidaTriangulo(tri);

  return tri;
}

void ValidaTriangulo(tTriangulo tri){
  float distp1p2 = distancia(tri.p1, tri.p2),
        distp1p3 = distancia(tri.p1, tri.p3),
        distp2p3 = distancia(tri.p2, tri.p3);

  if( ( abs(distp1p3 - distp2p3) < distp1p2 && distp1p2 < distp1p3 + distp2p3 ) && ( abs(distp1p2 - distp2p3) < distp1p3 && distp1p3 < distp1p2 + distp2p3 ) &&
      ( abs(distp1p2 - distp1p3) < distp2p3 && distp2p3 < distp1p2 + distp1p3 ) ){
        return 1;
  } else{
    printf("Triangulo Invalido!\n");
    exit(0);
  }
   

  
}