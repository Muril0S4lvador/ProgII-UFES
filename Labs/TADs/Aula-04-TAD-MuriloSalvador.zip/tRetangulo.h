#ifndef TRETANGULO_H
#define TRETANGULO_H
#include "tPonto.h"

typedef struct{
  tPonto p1, p2;
}tRetangulo;

tRetangulo criaRetangulo(tPonto p1, tPonto p2);

/**
 * As funcoes abaixo conferem se os dois pontos
 * que formam o retangulo nao sao o mesmo
 * caso sejam, nao ha retangulo e o programa para
*/

void ValidaRetangulo(tPonto p1, tPonto p2);

ValidaPontoX(float x1, float x2);

ValidaPontoY(float y1, float y2);

#endif