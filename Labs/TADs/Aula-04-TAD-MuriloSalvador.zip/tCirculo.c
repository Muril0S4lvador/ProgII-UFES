#include "tCirculo.h"
#include <stdlib.h>


tCirculo criaCirculo(tPonto p, float r)
{
  tCirculo c = {p, r};
  VerificaCirculo(c);

  return c;
}
float calcularArea(tCirculo c){
    float area = PI*c.raio*c.raio;
	
     return area;
}

void imprimeCirculo (tCirculo c){
  
  imprime(c.p);
	printf ("r: %.2f \n", c.raio);

}

static int VerificaRaio(float r){
  if( r <= 0 ) return 0;
  else return 1;
}

void VerificaCirculo(tCirculo c){
  int valid = VerificaRaio(c.raio);

  if( valid == 0 ){
    printf("Raio Invalido!\n");
    exit(0);
  }
}