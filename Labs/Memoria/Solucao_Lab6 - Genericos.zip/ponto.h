#ifndef PONTO_H
#define PONTO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARQUIVO "pontos.bin"
#define INICIAL_ARR 10

typedef struct tPonto tPonto;

typedef struct tPonto_arr tPontos_arr;

tPonto * CriarPonto(DESTE_TIPO_ x, DESTE_TIPO_ y);

void ImprimirPonto(tPonto *p);

void LiberarPonto(tPonto *p);

void salvarPonto(tPonto *p,FILE *f);

tPonto * carregarArquivo(FILE *fp);

tPontos_arr *inicializarTPontos();

void adicionarPonto(tPonto *p, tPontos_arr *tp);

void CopiarPontos(tPonto *src, tPonto *dest);
void salvarPontos(tPontos_arr *p,FILE *f);

tPontos_arr *carregarPontos(FILE *f);

void imprimirPontosArr(tPontos_arr *p);

#endif