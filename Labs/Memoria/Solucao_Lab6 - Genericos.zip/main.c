#include <stdio.h>

#define DESTE_TIPO_ double
#define FORMATO "%.2f"
#define PONTOS 5
#include "ponto.h"

int main(void) {

  tPonto *p = 
   CriarPonto(7.89,9.76);

  ImprimirPonto(p);

  FILE *fp;
  salvarPonto(p,fp);
  

  tPonto *p2= carregarArquivo(fp);
  ImprimirPonto(p2);

  LiberarPonto(p);
  LiberarPonto(p2);

   srand(1);
 tPontos_arr * p_arr = inicializarTPontos();
 for (int i=0; i < PONTOS; i++ )
   {
     //Aqui assume o que DESSE TIPO é real
     p = CriarPonto( ((float)rand()/(float)(RAND_MAX)) *100,  ((float)rand()/(float)(RAND_MAX)) * 100);
     
    // ImprimirPonto(p);
     adicionarPonto(p, p_arr);
     LiberarPonto(p);
   }

    imprimirPontosArr(p_arr);
    salvarPontos(p_arr, fp);
    FILE *fPts;
     tPontos_arr * p_arr2 = carregarPontos(fPts);
   printf("\n\nPONTOS CARREGADOS\n\n");
   imprimirPontosArr(p_arr2);
  
 // printf("Hello World\n");
  return 0;
}