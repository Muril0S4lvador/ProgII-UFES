
#define DESTE_TIPO_ double
#define FORMATO "%.2f"

#include "ponto.h"


struct tPonto{
  DESTE_TIPO_ x;
  DESTE_TIPO_ y;
};

struct tPonto_arr
{
   tPonto *pontos;
   size_t qtd;
   size_t tamArr;
};

tPonto * CriarPonto(DESTE_TIPO_ x, DESTE_TIPO_ y)
{
  tPonto *p = malloc(sizeof *p);
  if (p ==NULL)
    exit(EXIT_FAILURE);

  p->x = x;
  p->y = y;

  return  p;
}

void LiberarPonto(tPonto *p)
{
  free(p);
  p = NULL;
}

void ImprimirPonto(tPonto *p)
{
  char formato[15] = "{";
    strcat(formato,FORMATO); //adicionando o valor do meu formato
  strcat(formato,", ");
  strcat(formato, FORMATO);
  strcat(formato,"}");
  printf(formato, p->x, p->y);
  printf("\n");
}



void salvarPonto(tPonto *p,FILE *f)
{
  f = fopen(ARQUIVO,"wb");

  if (f == NULL)
  {
    printf("Erro abertura do arquivo!!");
    exit(EXIT_FAILURE);
  }
  fwrite(p,sizeof(*p),1, f);
  
  fclose(f);
}

tPonto * carregarArquivo(FILE *fp)
{
   fp = fopen(ARQUIVO,"wb");

  if (fp == NULL)
  {
    printf("Erro abertura do arquivo!!");
    exit(EXIT_FAILURE);
  }

  tPonto *p = malloc(sizeof *p);
  fread(p,sizeof(*p), 1, fp);

  return p;
}

tPontos_arr *inicializarTPontos(){
  tPontos_arr *pts = malloc(sizeof(tPontos_arr *));

  pts->pontos = calloc(sizeof(tPonto *),INICIAL_ARR);
  pts->qtd = 0;
  pts->tamArr = INICIAL_ARR;

  return pts;
  
}

void adicionarPonto(tPonto *p, tPontos_arr * tp)
{
  if (tp->qtd+1 > tp->tamArr)
  {
    tp->pontos = realloc(tp->pontos, 2*sizeof(tPonto *)*tp->tamArr);
  }

  CopiarPontos(p, &tp->pontos[tp->qtd]);
  tp->qtd++;
  
}

void CopiarPontos(tPonto *src, tPonto *dest)
{
  dest->x = src->x;
  dest->y = src->y;
}

void salvarPontos(tPontos_arr *p,FILE *fp)
{
    fp = fopen(ARQUIVO,"wb");

  if (fp == NULL){
      printf("Erro na abertura do arquivo\n");
      exit(1);
    }

    //grava todos os cadastros do array pontos
    fwrite(p, sizeof(*p), 1, fp);
    fclose(fp);
}

tPontos_arr *carregarPontos(FILE *fp)
{
    fp = fopen(ARQUIVO,"rb");

  if (fp == NULL){
      printf("Erro na abertura do arquivo\n");
      exit(1);
    }

   tPontos_arr *p= malloc(sizeof *p);

   long t = fread(p, sizeof *p, 1, fp);

   return p;  
}

void imprimirPontosArr(tPontos_arr *p)
{
  for (int i =0; i < p->qtd; i++)
    ImprimirPonto(&p->pontos[i]);
}