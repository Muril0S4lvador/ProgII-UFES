#include <stdio.h>
#include <stdlib.h>

void PreencheVetor(int vet[], int tam, int n){
    int *p, i;
    p = vet;

    for(i = 0; i < tam; i++){
        *(p+i) = n;
    }
}

void ImprimeVetor(int vet[], int tam){
    int *p, i;
    p = vet;

    for(i = 0; i < tam; i++){
        printf("%d ", *(p+i));
    }
    printf("\n");
}

int main(){
    int tam, n;
    printf("Qual o tamanho do seu vetor? ");
    scanf("%d", &tam);
    int vet[tam];

    PreencheVetor(vet, tam, 0);
    printf("\nVetor Inicializado:\n");
    ImprimeVetor(vet, tam);

    printf("\nDigite um numero para preencher todo o seu vetor com ele: ");
    scanf("%d", &n);
    PreencheVetor(vet, tam, n);
    ImprimeVetor(vet, tam);
}