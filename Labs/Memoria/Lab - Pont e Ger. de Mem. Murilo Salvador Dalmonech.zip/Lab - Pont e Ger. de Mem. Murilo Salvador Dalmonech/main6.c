#include <stdio.h>
#include <stdlib.h>

void LeDadosParaVetor(int vet[], int tam){
    int *p, i, n;
    p = vet;

    for(i = 0; i < tam; i++){
        scanf("%d", &n);
        *(p+i) = n;
    }
}

void OrdeneCrescente(int vet[], int tam){
    int i, j, *pi, *pj;

    for(i = 0; i<tam-1; i++){
        pi = &vet[i];
        for(j = i+1; j < tam; j++){
            pj = &vet[j];

            if( *pi > *pj ){
                int x;
                x = *pi; 
                *pi = *pj; 
                *pj = x;
            }
        }
    }

}

void ImprimeDadosDoVetor(int vet[], int tam){
    int *p, i;
    p = vet;

    for(i = 0; i < tam; i++){
        printf("%d ", *(p+i));
    }
    printf("\n");
}

int main(int argc, char * argv[]){
    int casos;
    scanf("%d", &casos);

    while(casos){
        int tam;
        scanf("%d", &tam);
        int vet[tam];

        LeDadosParaVetor(vet, tam);
        OrdeneCrescente(vet, tam);
        ImprimeDadosDoVetor(vet, tam);
        casos--;
    }

    return 0;
}