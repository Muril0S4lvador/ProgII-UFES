#include <stdio.h>
#include <stdlib.h>

int main(){
    int d1 = 0, d2 = 0;
    int* pd1, *pd2;
    pd1 = &d1;
    pd2 = &d2;

    (pd1 > pd2) ? printf("&d1 = %p\n", pd1) : printf("&d2 = %p\n", pd2);

    return 0;
}