#include <stdio.h>
#include <stdlib.h>

int main(){
    int d=0;
    float f=0;
    char c='c';
    printf("\n**ANTES DE MUDAR**\n\nVALORES DAS VARIAVEIS\nint d = %d\nfloat f = %.2f\nchar c = %c\n", d, f, c);

    int* pd;
    float* pf;
    char* pc;

    printf("\nENDERECO DOS PONTEIROS\nint* pd = %p\nfloat* pf = %p\nchar* pc = %p\n", pd, pf, pc);

    pd = &d;
    pf = &f;
    pc = &c;
    printf("\n\n**DEPOIS DE MUDAR**\n\nENDERECOS DOS PONTEIROS\nint* pd = %p\nfloat* pf = %p\nchar* pc = %p\n", pd, pf, pc);
    printf("\nVALORES DOS ENDERECOS\nint* pd = %d\nfloat* pf = %.2f\nchar* pc = %c\n", *pd, *pf, *pc);

    *pd = 10;
    *pf = 25.59;
    *pc = 'm';
    printf("\nVALORES DAS VARIAVEIS NOVOS\nint d = %d\nfloat f = %.2f\nchar c = %c\n", d, f, c);
    printf("\nVALORES DOS ENDERECOS NOVOS\nint* pd = %d\nfloat* pf = %.2f\nchar* pc = %c\n", *pd, *pf, *pc);

    return 0;
}