#ifndef _RETANGULO_H_
#define _RETANGULO_H_

typedef struct retangulo tRetangulo;

tRetangulo *CriaRetangulo(int comp, int larg);

tRetangulo *CalculaAreaRet(tRetangulo *ret);

tRetangulo *AdicionaRetangulo(tRetangulo *r, tRetangulo *f, int qtd);

double ObtemAreaRet(tRetangulo *r, int i);

double ObtemAreaTotalRet(tRetangulo *ret, int qtd);

#endif