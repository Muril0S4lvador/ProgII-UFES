#include <stdio.h>
#include "circulo.h"
#include "retangulo.h"
#include "triangulo.h"
#include "terreno.h"

int main(void) {
  int qtd, i, raio, larg, comp, alt, base;
  char c;
  double desvio, media, areaTotal;

  scanf("%d", &qtd);

  Terreno_pt t = InicializaTerreno(qtd);

  for(i=0; i<=qtd; i++){
    scanf("%c", &c);
    
    if( c == 'C' ){
      scanf("%d", &raio);
      scanf("%*c");

      tCirculo *c = CriaCirculo( raio );
      c = CalculaAreaCirc( c );
      t = adicionarArea(t, c, CIRCULO);
      
    } else if( c == 'R' ){
      scanf("%d %d", &comp, &larg);
      scanf("%*c");

      tRetangulo *ret = CriaRetangulo(comp, larg);
      ret = CalculaAreaRet( ret );
      t = adicionarArea(t, ret, RETANGULO);
      
    } else if( c == 'T' ){
        scanf("%d %d", &base, &alt);
        scanf("%*c");

        tTriangulo *tri = CriaTriangulo(base, alt);
        tri = CalculaAreaTri( tri );
        t = adicionarArea(t, tri, TRIANGULO);
      
    }
  }
  
  areaTotal = AreaTotal(t);
  media = Media(t, areaTotal);
  desvio = DesvioPadrao(t, media);
  
  
  ImprimeDesmatamento( media );
  ImprimeDesvio( desvio );
  LiberarTerreno(t);
  
  return 0;
}