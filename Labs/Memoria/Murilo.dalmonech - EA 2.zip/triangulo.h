#ifndef _TRIANGULO_H_
#define _TRIANGULO_H_

typedef struct triangulo tTriangulo;

tTriangulo *CriaTriangulo(int base, int alt);

tTriangulo *CalculaAreaTri(tTriangulo *tri);

tTriangulo *AdicionaTriangulo(tTriangulo *t, tTriangulo *f, int qtd);

double ObtemAreaTri(tTriangulo *t, int i);

double ObtemAreaTotalTri(tTriangulo *tri, int qtd);

#endif