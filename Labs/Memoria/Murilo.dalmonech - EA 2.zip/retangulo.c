#include "retangulo.h"
#include <stdio.h>
#include <stdlib.h>
#define MULTARET 0.8

struct retangulo{
  int comprimento;
  int largura;
  float area;
};

tRetangulo *CriaRetangulo(int comp, int larg) {
  tRetangulo *ret = (tRetangulo*) malloc(sizeof(struct retangulo));

  ret->comprimento = comp;
  ret->largura = larg;

  return ret;
}

tRetangulo *CalculaAreaRet(tRetangulo *ret) {
  int AreaR;

  AreaR = ret->comprimento * ret->largura;
  ret->area = AreaR/10000;

  return ret;
}

tRetangulo *AdicionaRetangulo(tRetangulo *r, tRetangulo *f, int qtd){
  int i;

  for(i = 0; i < qtd; i++){
    if((r+i)->area > 0){
      continue;

    } else {
      (r+i)->area = f->area;
      (r+i)->comprimento = f->comprimento;
      (r+i)->largura = f->largura;

    }
  }

  return r;
}

double ObtemAreaRet(tRetangulo *r, int i){
  return (r+i)->area;
}

double ObtemAreaTotalRet(tRetangulo *ret, int qtd){
  int i;
  float soma = 0;

  for(i = 0; i < qtd; i++){
    soma = ObtemAreaRet(ret, i);
  }
  return soma;
}
