#include "terreno.h"
#include "circulo.h"
#include "triangulo.h"
#include "retangulo.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct terreno{
    tCirculo *circulo;
    tTriangulo *triangulo;
    tRetangulo *retangulo;
    int contCirc;
    int contTri;
    int contRet;
    int contTotal;
};

Terreno_pt InicializaTerreno(int tam){
    Terreno_pt t = (Terreno_pt) malloc(sizeof(Terreno));

    t->circulo = (tCirculo*) calloc(tam, sizeof(tCirculo*));
    t->triangulo = (tTriangulo*) calloc(tam, sizeof(tTriangulo*));
    t->retangulo = (tRetangulo*) calloc(tam, sizeof(tRetangulo*));

    t->contCirc = 0;
    t->contRet = 0;
    t->contTotal = 0;
    t->contTri = 0;

    return t;
}

Terreno_pt adicionarArea(Terreno_pt t, void * f, enum TERRENO n){
    t->contTotal++;

    switch( n ){
        case CIRCULO:
           t->circulo = AdicionaCirculo(t->circulo, f, t->contTotal);
          t->contCirc++;
            break;
        case RETANGULO:
            t->retangulo = AdicionaRetangulo(t->retangulo, f, t->contTotal);
          t->contRet++;

            break;
        case TRIANGULO:
            t->triangulo = AdicionaTriangulo(t->triangulo, f, t->contTotal);
          t->contTri++;

            break;
    }

    return t;
}

double AreaTotal(Terreno_pt t){
  double AreaCirc = ObtemAreaTotalCirc(t->circulo, t->contCirc), 
         AreaRet = ObtemAreaTotalRet(t->retangulo, t->contRet),
         AreaTri = ObtemAreaTotalTri(t->triangulo, t->contTri);

    return (AreaCirc + AreaRet + AreaTri);
}

double Media(Terreno_pt t, double AreaTotal){
    float n = t->contTotal;
    return (AreaTotal/n);
}

double DesvioPadrao(Terreno_pt t, double media){
    int i;
    double areaC = 0, areaT = 0, areaR = 0, desvio = 0;

    for(i = 0; i < t->contCirc; i++){
      areaC = ObtemAreaCirc(t->circulo, i);
      desvio += pow((areaC - media), 2);

    }

    for(i = 0; i < t->contRet; i++){
        areaR = ObtemAreaRet(t->retangulo, i);
        desvio += pow((areaR - media), 2);

    }

    for(i = 0; i < t->contTri; i++){
        areaT = ObtemAreaTri(t->triangulo, i);
        desvio += pow((areaT - media), 2);

    }
    desvio /= t->contTotal;
    desvio = sqrt(desvio);

    return desvio;
}

void ImprimeDesmatamento(double media){
  printf("Media de desmatamento:%.3lf\n", media);
}

void ImprimeDesvio(double desvio){
  printf("Desvio medio:%.3lf\n", desvio);
}

void LiberarTerreno(Terreno_pt t){
  free(t->circulo);
  free(t->retangulo);
  free(t->triangulo);
  free(t);
}
