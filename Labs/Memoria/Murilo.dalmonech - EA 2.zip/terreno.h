enum TERRENO{
    CIRCULO=0,
    RETANGULO=1,
    TRIANGULO=2,
};

/*Contem um vetor para cada tipo de forma, alem de armazenar o espaço 
utilizado por cada vetor*/
typedef struct terreno Terreno;

//Renomeando um ponteiro de Terreno
typedef Terreno * Terreno_pt;

/**
* Inicializa o struct terreno
*/
Terreno_pt InicializaTerreno(int tam);

/***
* Adiciona no Terreno t uma forma f no array descrito pelo enum TERRENO
*/
Terreno_pt adicionarArea(Terreno_pt t, void * f, enum TERRENO n);

/**
* Calcula a area total de desmatamente
*/
double AreaTotal(Terreno_pt t);

/**
* Calcula a média total de desmatamento
*/
double Media(Terreno_pt t, double AreaTotal);

/**
* Calcula o desvio padrão de desmatamento
*/
double DesvioPadrao(Terreno_pt t, double media);

void LiberarTerreno(Terreno_pt t);

void ImprimeDesmatamento(double media);

void ImprimeDesvio(double desvio);