#include "triangulo.h"
#include <stdio.h>
#include <stdlib.h>
#define MULTAT 0.7

struct triangulo{
  int base;
  int altura;
  float area;
};

tTriangulo *CriaTriangulo(int base, int alt) {
  tTriangulo *tri = (tTriangulo*) malloc (sizeof(struct triangulo));

  tri->altura = alt;
  tri->base = base;

  return tri;
}

tTriangulo *CalculaAreaTri(tTriangulo *tri) {
  int AreaT;

  AreaT = (tri->base * tri->altura) / 2;
  tri->area = AreaT/10000;

  return tri;
}

tTriangulo *AdicionaTriangulo(tTriangulo *t, tTriangulo *f, int qtd){
  int i;

  for(i = 0; i < qtd; i++){
    if((t+i)->area > 0){
      continue;

    } else {
      (t+i)->area = f->area;
      (t+i)->base = f->base;
      (t+i)->altura = f->altura;

    }
  }

  return t;
}

double ObtemAreaTri(tTriangulo *t, int i){
  return (t+i)->area;
}

double ObtemAreaTotalTri(tTriangulo *tri, int qtd){
  int i;
  float soma = 0;

  for(i = 0; i < qtd; i++){
    soma = ObtemAreaTri(tri, i);
  }
  return soma;
}
