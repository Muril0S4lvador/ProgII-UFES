#ifndef _CIRCULO_H_
#define _CIRCULO_H_

typedef struct circulo tCirculo;

tCirculo* CriaCirculo();

tCirculo *CalculaAreaCirc(tCirculo *c);

tCirculo *AdicionaCirculo(tCirculo *c, tCirculo *f, int qtd);

double ObtemAreaCirc(tCirculo *c, int i);

double ObtemAreaTotalCirc(tCirculo *c, int qtd);

#endif