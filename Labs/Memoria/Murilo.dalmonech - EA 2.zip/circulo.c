#include "circulo.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#define PI 3.1415
#define MULTAC 0.6

struct circulo{
  int raio;
  float area;
};

tCirculo* CriaCirculo(int raio) {
  tCirculo *c = (tCirculo*) malloc (sizeof (struct circulo));

  c->raio = raio;

  return c;
}

tCirculo *CalculaAreaCirc(tCirculo *c) {
  float areaC;

  areaC = pow((c->raio), 2) * PI;
  c->area = areaC/10000;

  return c;
}

tCirculo *AdicionaCirculo(tCirculo *c, tCirculo *f, int qtd){
  int i;

  for(i = 0; i < qtd; i++){
    if((c+i)->area > 0){
      continue;

    } else {
      (c+i)->area = f->area;
      (c+i)->raio = f->raio;

    }
  }

  return c;
}

double ObtemAreaCirc(tCirculo *c, int i){
  return (c+i)->area;  
}

double ObtemAreaTotalCirc(tCirculo *c, int qtd){
  int i;
  float soma = 0;

  for(i = 0; i < qtd; i++){
    soma = ObtemAreaCirc(c, i);
  }
  return soma;
}
