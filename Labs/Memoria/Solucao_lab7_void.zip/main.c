#include <stdio.h>
#include <stdlib.h>
#include "Terrenos.h"


int main() {
    int n;

    scanf("%d%*c", &n);

    Terrenos_pt t =  InicializaTerrenos(n);

    int i=0;

    char c;
    int aux1, aux2;
    while (n--){
        scanf("%c%*c", &c);

        switch (c) {
            case 'C':
                scanf("%d%*c", &aux1);
                adicionarArea(t, InicializaTerreno(criaCirculo(aux1), CIRCULO));
    
                break;
            case 'T':
                scanf("%d%d%*c", &aux1, &aux2);
                adicionarArea(t, InicializaTerreno(criaTriangulo(aux1, aux2), TRIANGULO));
                //printf("Preço: %.2f\n", calculaPrecoHectareTriangulos(t, 7000));
                break;
            case 'R':
                scanf("%d%d%*c", &aux1, &aux2);
                 adicionarArea(t, InicializaTerreno(criaRetangulo(aux1, aux2), RETANGULO));
                //printf("Preço: %.2f\n", calculaPrecoHectareRetangulo(r, 8000));
                break;
            default:
                printf("Erro: Entrada invalida!!\n");
                exit(1);
                break;
        }
        i++; 
        
    }
    printf("MEDIA DESMATAMENTO: %.3f\n", Media(t));
    printf("DESVIO PADRAO: %.3f\n", DesvioPadrao(t));

    liberaTerrenos(t);
    
    return 0;
}