//
// Created by AbeSantos on 15/07/2021.
// Modified by Alessandro on 23/09/2022
//

#include "Triangulos.h"



struct triangulos{
    int comp;
    int larg;
};


tTriangulo * criaTriangulo(int c, int l)
{
  
  tTriangulo *r = malloc(sizeof (*r));
  if (r != NULL)
  {
    r->comp =c;
    r->larg = l;

    return r;
  }

    return NULL;

}

void liberaTriangulo(tTriangulo * r)
{
  if (r != NULL)
    free(r);

  r = NULL;
}


double calculaHectareTriangulos(tTriangulo *t){
    return ((double)(t->larg * t->comp)/2)/10000;
}

double calculaPrecoHectareTriangulos(tTriangulo * t, double preco){
    return preco * calculaHectareTriangulos(t);
}