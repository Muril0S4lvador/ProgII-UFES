#include "Terrenos.h"

struct terreno{
    void * terreno;
    enum TERRENO tipo;
};


Terreno_pt InicializaTerreno(void * terreno, enum TERRENO tipo)
{
    Terreno_pt t = malloc(sizeof *t);
    if (t == NULL)
        exit(1);

    t->terreno = terreno;
    t->tipo = tipo;

    return t;
}

double  Area(Terreno_pt t)
{
    if (t !=NULL)
    {
        switch (t->tipo)
        {
        case CIRCULO:
            return calculaHectareCirculo(((tCirculo *)t->terreno));
            break;
         case RETANGULO:
            return calculaHectareRetangulo((tRetangulo *)t->terreno);
            break;

        case TRIANGULO:
            return calculaHectareTriangulos((tTriangulo *)t->terreno);
            break;
        default:
            break;
        }
    }
    return 0;
}


void liberaTerreno(Terreno_pt t)
{
  if (t != NULL)
    free(t);

  t = NULL;
}