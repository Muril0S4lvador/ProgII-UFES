//
// Created by AbeSantos on 15/07/2021.
// Modified by Alessandro on 23/09/2022
//

#include "Retangulos.h"

struct retangulos{
    int comp;
    int larg;
};

tRetangulo * criaRetangulo(int c, int l)
{
  
  tRetangulo *r = malloc(sizeof(tRetangulo));
  if (r != NULL)
  {
    r->comp =c;
    r->larg = l;

    return r;
  }

    return NULL;

}

void liberaRetangulo(tRetangulo * r)
{
  if (r != NULL)
    free(r);

  r = NULL;
}


double calculaHectareRetangulo(tRetangulo *r){
    return ((double)(r->comp * r->larg)/10000.00);
}

double calculaPrecoHectareRetangulo(tRetangulo * r, double preco){
    return preco * calculaHectareRetangulo(r);
}