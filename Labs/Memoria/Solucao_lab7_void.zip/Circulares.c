//
// Created by AbeSantos on 15/07/2021.
// Modified by Alessandro on 23/09/2022
//

#include "Circulares.h"


struct circulo{
    double raio;
};

tCirculo * criaCirculo(int raio)
{
  
  tCirculo *r = malloc(sizeof *r);
  if (r != NULL)
  {
    r->raio =raio;
    
     return r;
  }

    return NULL;

}

void liberaCirculo(tCirculo * r)
{
  if (r != NULL)
    free(r);

  r = NULL;
}

double calculaHectareCirculo(tCirculo * c){
    return ((double)(PI * c->raio * c->raio)/10000);
}

double calculaPrecoHectareCirculo(tCirculo * c, double preco){
    return preco * calculaHectareCirculo(c);
}