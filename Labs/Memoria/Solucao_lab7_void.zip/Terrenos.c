#include "Terrenos.h"


struct terrenos{
    Terreno * terreno;
    int qtde;
};



Terrenos_pt InicializaTerrenos(int qtde)
{
     Terrenos_pt t = malloc(sizeof *t);
    if (t == NULL)
        exit(1);

    t->terreno =  malloc(sizeof (Terreno_pt *)*qtde);
    t->qtde = 0;

    return t;
}



void adicionarArea(Terrenos_pt t, Terreno * f)
{
    if (t !=NULL)
    {
        ((Terreno **)t->terreno)[t->qtde] = f;
        t->qtde++;

    }
}


double  AreaTotal(Terrenos_pt t)
{
    double d =0;
    for (int i =0; i < t->qtde; i++)
        d+=Area(((Terreno **)t->terreno)[i]);


    return d;
}



double Media(Terrenos_pt t)
{
    double d =AreaTotal(t);
    //for(int i =0; i < size; i++)
    //    d += Area(terrenos[i]);

    return d/t->qtde;
}



double DesvioPadrao(Terrenos_pt t)
{
    double m= Media(t);

    double d =0;

    for (int i =0; i < t->qtde; i++)
        d+=pow(Area(((Terreno **)t->terreno)[i])-m,2);


    d /= t->qtde;

    return sqrt(d);
}



void liberaTerrenos(Terrenos_pt t)
{
  if (t != NULL)
    free(t);

  t = NULL;
}
