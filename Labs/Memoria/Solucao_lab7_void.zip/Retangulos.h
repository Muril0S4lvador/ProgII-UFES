//
// Created by AbeSantos on 15/07/2021.
// Modified by Alessandro on 23/09/2022
// Vinicius 17/10/22

#ifndef EXERC1_RETANGULOS_H
#define EXERC1_RETANGULOS_H

#include <stdlib.h>

typedef struct retangulos tRetangulo;

tRetangulo * criaRetangulo(int, int);

void liberaRetangulo(tRetangulo *);


double calculaHectareRetangulo(tRetangulo *r);

double calculaPrecoHectareRetangulo(tRetangulo * ret, double preco);

#endif //EXERC1_RETANGULOS_H
