//
// Created by AbeSantos on 15/07/2021.
// Modified by Alessandro on 23/09/2022
// Vinicius 

#ifndef EXERC1_CIRCULARES_H
#define EXERC1_CIRCULARES_H

#include <stdlib.h>

#define PI 3.1415

typedef struct circulo tCirculo;

tCirculo *criaCirculo(int raio);

void liberaCirculo(tCirculo * r);

double calculaHectareCirculo(tCirculo * c);

double calculaPrecoHectareCirculo(tCirculo * c, double preco);

#endif //EXERC1_CIRCULARES_H
