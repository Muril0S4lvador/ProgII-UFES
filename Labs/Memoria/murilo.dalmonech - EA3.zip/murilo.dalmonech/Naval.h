#ifndef _NAVAL_H_
#define _NAVAL_H_

#include <stdio.h>
#include <stdlib.h>

#define M 10
#define N 10
#define NAVIO 'o'
#define NAVIODESTRUIDO 'x'
#define VAZIO '-'
#define CAMINHOENTRADA "navios.dat"

typedef struct naval tNaval;

tNaval** InicializaMapaNaval(tNaval **mat);

tNaval** AtualizaMatriz(int m, int n, char c, tNaval **mat);

tNaval** InicializaCaratcteres(tNaval **mat);

tNaval* MudaCaracter(tNaval *mat, char c, int i);

void ImprimeMatriz(tNaval **mat);

void ImprimeLinhaMatriz(tNaval *mat);

void LiberaMatriz(tNaval **mat);

FILE* AbreArquivo(FILE *arquivo);

int ExisteNavio(tNaval **mat, int m, int n);

#endif