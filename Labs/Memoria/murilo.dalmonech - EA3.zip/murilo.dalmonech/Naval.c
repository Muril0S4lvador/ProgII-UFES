#include "Naval.h"

struct naval{
    char carac;
};

tNaval** InicializaMapaNaval(tNaval **mat){
    int i;

    mat = (tNaval**) malloc(M * sizeof(tNaval*));

    for(i = 0; i < M; i++){
        mat[i] =(tNaval*) malloc(N * sizeof(struct naval));
    }

    mat = InicializaCaratcteres(mat);

    return mat;
}

tNaval** InicializaCaratcteres(tNaval **mat){
    int i, j;

    for(i = 0; i < M; i++){
        for(j = 0; j < N; j++){
            mat[i] = MudaCaracter(mat[i], VAZIO, j);
        }
    }
    return mat;
}

tNaval* MudaCaracter(tNaval *mat, char c, int n){
    (mat+n)->carac = c;

    return mat;
}

tNaval** AtualizaMatriz(int m, int n, char c, tNaval **mat){
    m--; n--;

    mat[m] = MudaCaracter(mat[m], c, n);
    
    return mat;
}

void ImprimeMatriz(tNaval **mat){
    int i;

    for(i = 0; i < M; i++){
        ImprimeLinhaMatriz(mat[i]);
        printf("\n");
    }
}

void ImprimeLinhaMatriz(tNaval *mat){
    int i;

    for(i = 0; i < N; i++){ 
        printf("%c ", (mat+i)->carac);
    }
}

void LiberaMatriz(tNaval **mat){
    int i;

    for(i = 0; i < M; i++){
        free(mat[i]);
        mat[i] = NULL;
    }
    free(mat);
    mat = NULL;

}

FILE* AbreArquivo(FILE *arquivo){
    char endereco[21] = CAMINHOENTRADA;
    arquivo = fopen(endereco, "rb");

    if( !arquivo ){
        printf("\nNAO ENCONTRADO O ARQUIVO %s\n", endereco);
        exit(0);
    }

    return arquivo;
}

int ExisteNavio(tNaval **mat, int m, int n){
    m--; n--;
    return ((mat[m]+n)->carac == NAVIO) ? 1 : 0;
}
