#include "Naval.h"

int main(){
    int m, n, *buffer = calloc(2, sizeof(int)), pecas = 0, navio;
    tNaval **mat = InicializaMapaNaval(mat);
    FILE *arquivo = AbreArquivo(arquivo);

    /* Inicializando o jogo */
    while( fread(buffer, sizeof(int), 2, arquivo) ){
        mat = AtualizaMatriz(buffer[0], buffer[1], NAVIO, mat);
        pecas++;
    }
    ImprimeMatriz(mat);


    /* Durante o jogo */
    while( pecas ){
        scanf("%d,%d", &m, &n);
        scanf("%*c");
        system("clear");
        navio = ExisteNavio(mat, m, n);

        if( navio ){
            mat = AtualizaMatriz(m, n, NAVIODESTRUIDO, mat);
            pecas--;
        }
        ImprimeMatriz(mat);
    }

    /* Fim do jogo */
    system("clear");
    printf("\n\nJOGO FINALIZADO!\n\n");
    ImprimeMatriz(mat);

    free(buffer);
    LiberaMatriz(mat);
    fclose(arquivo);

    return 0;
}