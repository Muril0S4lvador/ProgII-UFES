#include "vetor.h"

struct vetor{
    void *nums;
    int tipo;
    int tam;
};

Vetor *criar(int tam, int tipo){
    Vetor *v;
    v = (Vetor*) malloc( sizeof( struct vetor) );
    v->tam = tam;

    switch( tipo ){
        case INT:
            v->nums = (int*) malloc( tam * sizeof(int) );
            v->tipo = INT;
            break;

        case FLOAT:
            v->nums = (float*) malloc( tam * sizeof(float) );
            v->tipo = FLOAT;
            break;

        case DOUBLE:
            v->nums = (double*) malloc( tam * sizeof(double) );
            v->tipo = DOUBLE;
            break;

        default : return NULL;
    }

    return v;
}

void preencher(Vetor *v){

    for( int i = 0; i < v->tam; i++ ){

        switch( v->tipo ){

            case INT :
                ((int*)v->nums)[i] = (int)rand( )%MAX;
                break;

            case FLOAT :
                ((float*)v->nums)[i] = (float)rand( )/RAND_MAX*MAX;
                break;

            case DOUBLE :
                ((double*)v->nums)[i] = (double)rand( )/RAND_MAX*MAX;
                break;
        }
    }
}

void imprimir(Vetor *v){

    for( int i = 0; i < v->tam; i++ ){

        switch( v->tipo ){

            case INT :
                printf("%d ", ((int*)v->nums)[i]);
                break;

            case FLOAT :
                printf("%.3lf ", ((float*)v->nums)[i]);
                break;

            case DOUBLE :
                printf("%.3lf ", ((double*)v->nums)[i]);
                break;
        }
    }
    printf("\n");
}

void liberar(Vetor *v){
    free(v->nums);
    free(v);
    v = NULL;
}


double media(Vetor *v){
    double media = 0.0;

    switch( v->tipo ){
        case INT:
            media = media_int(v);
            break;

        case FLOAT:
            media = media_float(v);
            break;

        case DOUBLE:
            media = media_double(v);
            break;
    }

    return media;
}

double media_int(Vetor *v){
    double media = 0.0;

    for(int i = 0; i < v->tam; i++){
        media += ((int*)v->nums)[i];
    }

    return media/v->tam;
}

double media_float(Vetor *v){
    double media = 0.0;

    for(int i = 0; i < v->tam; i++){
        media += ((float*)v->nums)[i];
    }

    return media/v->tam;
}

double media_double(Vetor *v){
    double media = 0.0;

    for(int i = 0; i < v->tam; i++){
        media += ((double*)v->nums)[i];
    }

    return media/v->tam;
}

double variancia(Vetor *v){
    double soma = 0,
           med = media(v);
    int denominador = v->tam - 1;

    for(int i = 0; i < v->tam; i++){

        switch( v->tipo ){
            case INT:
                soma += pow ( ((int*)v->nums)[i] - med, 2);
                break;

            case FLOAT:
                soma += pow ( ((float*)v->nums)[i] - med, 2);
                break;
            
            case DOUBLE:
                soma += pow ( ((double*)v->nums)[i] - med, 2);
                break;
        }
    }

    return soma/denominador;
}

double desvioPadrao(Vetor *v){
    double var = variancia(v);
    return sqrt(var);
}

double calcular(Vetor *v, char c){
    double resp = 0;

    switch( c ){
        case MEDIA:
            resp = operacao(v, media);
            break;

        case VARIANCIA:
            resp = operacao(v, variancia);
            break;

        case DESVIO:
            resp = operacao(v, desvioPadrao);
            break;
    }

    return resp;
}


double operacao(Vetor *v, fptrOp f){
    return f(v);
}