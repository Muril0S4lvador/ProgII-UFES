#include "vetor.h"

int main(int argc,char *argv[]){
    int tam, seed;

    if(argc < 3) exit(1);

    tam = strtol(argv[1], NULL, 10);
    seed = strtol(argv[2], NULL, 10);

    srand(seed);

    Vetor *d = criar(tam, DOUBLE),
          *f = criar(tam, FLOAT),
          *i = criar(tam, INT);

    preencher(d);
    preencher(f);
    preencher(i);

    printf("Vetor de ints:\n");
    imprimir(i);
    printf("Media = %.3lf\n", calcular(i, 'm'));
    printf("Variancia = %.3lf\n", calcular(i, 'v'));
    printf("Desvio padrao = %.3lf\n", calcular(i, 'd'));

    printf("\nVetor de floats:\n");
    imprimir(f);
    printf("Media = %.3lf\n", calcular(f, 'm'));
    printf("Variancia = %.3lf\n", calcular(f, 'v'));
    printf("Desvio padrao = %.3lf\n", calcular(f, 'd'));

    printf("\nVetor de doubles:\n");
    imprimir(d);
    printf("Media = %.3lf\n", calcular(d, 'm'));
    printf("Variancia = %.3lf\n", calcular(d, 'v'));
    printf("Desvio padrao = %.3lf\n", calcular(d, 'd'));

    liberar(i);
    liberar(f);
    liberar(d);

    return 0;
}
