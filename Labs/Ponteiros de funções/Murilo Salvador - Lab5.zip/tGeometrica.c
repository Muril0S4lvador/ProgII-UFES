#include "tGeometrica.h"

typedef float (*fptrArea)(void *);

float area(fptrArea forma, void *x)
{
  return forma(x);
}
// Dado um caracter - retorna a função de area
fptrArea selecionaFuncao(char code){
  switch( code ){
    case 'c': return areaCirculo;
    case 'r': return areaRetangulo;
    case 't': return areaTriangulo;
    case 'q': return areaQuadrado;
  return NULL;
  }
}

// Utiliza a função anterior para selecionar a função que vai calcular a área *
float  calcularArea(char code, void *x){
  return selecionaFuncao(code)(x);
}


