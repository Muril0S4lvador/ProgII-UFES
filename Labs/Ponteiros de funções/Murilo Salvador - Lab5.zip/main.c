#include "tGeometrica.h"

int main()
{ 
   tPonto centro = criaPonto(10.0, 20.5);
   tCirculo c = criaCirculo(centro, 5.0);
   
   imprimeCirculo(c);

  printf("Area: %.2f\n", calcularAreaCirculo(c));

  tPonto p1 = criaPonto(5.0, 6.7);

  tPonto p2 = criaPonto(15.0, 16.7);
  
  tPonto p3 = criaPonto(51.0, 61.7);

  tCirculo *c2 = &c;
  
  printf("fptrArea: %.2f\n", area(areaCirculo, c2));

  printf("Area Circulo: %.2f\n", calcularArea('c', c2));

  tRetangulo r = criaRetangulo(p1, p2);
  tRetangulo *r2 = &r;
  printf("Area Retangulo: %.2lf\n", calcularArea('r', r2));

  tTriangulo t = criaTriangulo(20, 15);
  tTriangulo* t2 = &t;
  printf("Area Triangulo: %.2lf\n", calcularArea('t', t2));

  tQuadrado q = criaQuadrado(5);
  tQuadrado *q2 = &q;
  printf("Area Quadrado: %2.lf\n", calcularArea('q', q2));
  
   return 0;
}
