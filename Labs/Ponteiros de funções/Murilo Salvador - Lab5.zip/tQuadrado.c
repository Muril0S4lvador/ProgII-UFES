#include <stdio.h>
#include <stdlib.h>
#include "tQuadrado.h"

tQuadrado criaQuadrado(float l){
    tQuadrado q;
    q.lado = l;

    return q;
}

float areaQuadrado(void *r)
{
  tQuadrado *q2 = (tQuadrado *)r;
  return (q2->lado * q2->lado);
}