#ifndef TQUADRADO_H
#define TQUADRADO_H

typedef struct{
    float lado;
}tQuadrado;

tQuadrado criaQuadrado(float l);

float areaQuadrado(void *r);

#endif