#include <stdio.h>
#include <stdlib.h>
#include "tTriangulo.h"

tTriangulo criaTriangulo(float altura, float base){
  tTriangulo tri;
  tri.altura = altura;
  tri.base = base;

  return tri;
}

float areaTriangulo(void *r)
{
  tTriangulo *t2 = (tTriangulo *)r;
  return (t2->base * t2->altura)/2;
}