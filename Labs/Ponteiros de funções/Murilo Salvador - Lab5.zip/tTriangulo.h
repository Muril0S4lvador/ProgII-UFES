#ifndef TTRIANGULO_H
#define TTRIANGULO_H
#include "tPonto.h"

typedef struct{
  float base, altura;
}tTriangulo;

tTriangulo criaTriangulo(float altura, float base);

float areaTriangulo(void *r);

#endif