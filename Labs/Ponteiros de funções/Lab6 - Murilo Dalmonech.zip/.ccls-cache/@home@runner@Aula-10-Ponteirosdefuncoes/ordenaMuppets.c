/* Baseado em https://www.gnu.org/software/libc/manual/html_node/Search_002fSort-Example.html 

Atenção: Código inflinge algumas organizações e design de implementação que vimos até aqui para focarmos apenas nas questõe de ponteiro de função:
*/

#include <stdio.h>


struct criatura
{
  const char* nome;
  const char* especie;
};

struct criatura muppets[] =
  {
    {"Kermit", "sapo"},
    {"Piggy", "porco"},
    {"Gonzo", "Vaisaber"},
    {"Fozzie", "urso"},
    {"Sam", "aguia"},
    {"Robin", "sapo"},
    {"Animal", "animal"},
    {"Camilla", "galinha"},
    {"Sweetums", "monstro"},
    {"Dr. Strangepork", "porco"},
    {"Link Hogthrob", "porco"},
    {"Zoot", "humano"},
    {"Dr. Bunsen Honeydew", "humano"},
    {"Beaker", "humano"},
    {"Swedish Chef", "humano"}
  };


/* Imprime a informação sobre a criatura
. */
void
print_criatura(const struct criatura  *c)
{
  printf ("%s, o %s\n", c->nome, c->especie);
}


int main(void) {
  
  int numMuppets = sizeof(muppets)/sizeof(struct criatura);

  for (int i = 0; i < numMuppets; i++)
    print_criatura(&muppets[i]);

  printf("\n");

  
  
  /*3. Ordene as criaturas por nome utilizando a qsort da stdlib.
  */

  

  /* 
  4. Teste a função encontra_criatura procurando na main procurando um muppet que existe e outro que não existe.
    */

  
    /*5. Ordene as criaturas por idade utilizando a qsort da stdlib.
  */

   /* 
    6. Imprima a lista de criaturas da mesma espécie.
     */
  
  return 0;
}