/* Baseado em https://www.gnu.org/software/libc/manual/html_node/Search_002fSort-Example.html 

Atenção: Código inflige algumas organizações e design de implementação que vimos até aqui para focarmos apenas nas questões de ponteiro de função:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define  TAM_INICIAL 5

#define DEBUG 0

struct criatura
{
  const char* nome;
  const char* especie;
  int idade;
};

struct criatura muppets[] =
  {
    {"Kermit", "sapo", 12},
    {"Piggy", "porco", 89},
    {"Gonzo", "vaisaber", 25},
    {"Fozzie", "urso",15},
    {"Sam", "aguia",37},
    {"Robin", "sapo", 68},
    {"Animal", "animal", 90},
    {"Camilla", "galinha", 109},
    {"Sweetums", "monstro", 43},
    {"Dr. Strangepork", "porco", 61},
    {"Link Hogthrob", "porco", 87},
    {"Zoot", "humano", 60},
    {"Dr. Bunsen Honeydew", "humano", 21},
    {"Beaker", "humano", 8},
    {"Swedish Chef", "humano", 58}
  };



/* Imprime a informação sobre a criatura
. */
void
print_criatura(const struct criatura  *c)
{
  printf ("%s, o %s com %d anos.\n", c->nome, c->especie, c->idade);
}

int criatura_cmp(const void *v1, const void *v2)
{
   const struct criatura *c1 = v1;
   const struct criatura *c2 = v2;
   return strcmp(c1->nome, c2->nome);
}


int especie_cmp(const void *v1, const void *v2)
{
   const struct criatura *c1 = v1;
   const struct criatura *c2 = v2;
   return strcmp(c1->especie, c2->especie);
}


int criatura_idade_cmp(const void *v1, const void *v2)
{
   const struct criatura *c1 = v1;
   const struct criatura *c2 = v2;
           //c1->idade - c2->idade
   return (c1->idade > c2->idade) - (c1->idade < c2->idade);
}

void encontra_criatura(const char *criatura)
{

  int numMuppets = sizeof(muppets)/sizeof(struct criatura);
  
  struct criatura criatura_procurada; struct criatura *resultado;
  
  criatura_procurada.nome = criatura;

  //Criamos uma criatura  apenas para passar como  argumento na função de comparação
  resultado = bsearch(&criatura_procurada, muppets, numMuppets, sizeof(struct criatura), criatura_cmp);
  
  if (resultado)
     print_criatura(resultado);
  else
    printf("Nao encontrada %s.\n", criatura); 
}

/**
@brief Procura todos os elemntos da especies iguais. Funciona do seguinte modo:
Cria uma copia do array original e um array para os resultados com um tamanho inicial.

Realiza a procura do muppet no arrat copia, se encontrar, adiciona ao array de resultados e o remove do array copia. Repete essa operação enquanto houver resultado na pesquisa.

@param especie   String da especie procurada

@return  um array de struct criatura com todas as criaturas de uma especie.
*/
struct criatura * encontra_especies(char *especie)
{
  struct criatura criatura_procurada;

  struct criatura *resultado = NULL;

  struct criatura *especies_arr = malloc(sizeof *especies_arr * TAM_INICIAL);

  int numMuppets = sizeof(muppets)/sizeof(struct criatura);
  ///Gera uma copia do array original
  struct criatura *copia_cria = malloc(sizeof *copia_cria * numMuppets);

  memcpy(copia_cria, muppets, numMuppets * sizeof(struct criatura));
  

  //Ordena por especie
  qsort(copia_cria, numMuppets, sizeof(struct criatura), especie_cmp);

  #if DEBUG
  for (int i = 0; i < numMuppets; i++)
    print_criatura(&copia_cria[i]);
  #endif

   criatura_procurada.especie = especie;
   int qtdEspecies =0;
   do{

     resultado = bsearch(&criatura_procurada, copia_cria, numMuppets, sizeof(struct criatura),especie_cmp);

     if(resultado)
     {
         //calcula o index de onde esta o elemento
        int index = (int)((char *)resultado - (char *)copia_cria)/sizeof(struct criatura);

       especies_arr[qtdEspecies] =copia_cria[index];

       //remover o elemento em index
       memmove(copia_cria+index, copia_cria+index+1, (numMuppets-index) *sizeof(struct criatura));
       numMuppets--;
       qtdEspecies++;
     }

      
     
   }while(resultado != NULL);

  free(copia_cria);
  
  if (qtdEspecies == 0)
    printf("Nao encontrado");
  return especies_arr;
}

int main(void) {
  
  int numMuppets = sizeof(muppets)/sizeof(struct criatura);

  for (int i = 0; i < numMuppets; i++)
    print_criatura(&muppets[i]);

  printf("\n");

  
  
  /*3. Ordene as criaturas por nome utilizando a qsort da stdlib.
  */

  qsort(muppets, numMuppets,sizeof(struct criatura), criatura_cmp);

 for (int i = 0; i < numMuppets; i++)
     print_criatura(&muppets[i]);

  /* 
  4. Teste a função encontra_criatura procurando na main procurando um muppet que existe e outro que não existe.
    */
  encontra_criatura("Robin");

  encontra_criatura("Vinicius");
  
    /*5. Ordene as criaturas por idade utilizando a qsort da stdlib.
  */
  printf("\n\n 5. Ordene as criaturas por idade \n\n");
  qsort(muppets, numMuppets,sizeof(struct criatura), criatura_idade_cmp);

 for (int i = 0; i < numMuppets; i++)
     print_criatura(&muppets[i]);
    
   /* 
    6. Imprima a lista de criaturas da mesma espécie.
     */
printf("\n\n  6. Imprima a lista de criaturas da mesma espécie. \n\n");
  struct criatura *especies = encontra_especies("sapo");
  for (int i = 0; i < TAM_INICIAL; i++)
    if (&especies[i] != NULL && especies[i]. nome !=NULL)
      print_criatura(&especies[i]);
  return 0;
}