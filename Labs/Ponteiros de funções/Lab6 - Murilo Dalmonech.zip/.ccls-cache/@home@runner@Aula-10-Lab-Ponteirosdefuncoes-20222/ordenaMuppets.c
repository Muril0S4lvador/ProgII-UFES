/* Baseado em
https://www.gnu.org/software/libc/manual/html_node/Search_002fSort-Example.html

Atenção: Código inflige algumas organizações e design de implementação que vimos
até aqui para focarmos apenas nas questões de ponteiro de função:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct criatura {
  const char *nome;
  const char *especie;
  const int idade;
};

struct criatura muppets[] = {{"Kermit", "sapo", 10},
                             {"Piggy", "porco", 90},
                             {"Gonzo", "Vaisaber", 8},
                             {"Fozzie", "urso", 1},
                             {"Sam", "aguia", 35},
                             {"Robin", "sapo", 76},
                             {"Animal", "animal", 23},
                             {"Camilla", "galinha", 12},
                             {"Sweetums", "monstro", 22},
                             {"Dr. Strangepork", "porco", 22},
                             {"Link Hogthrob", "porco", 67},
                             {"Zoot", "humano", 25},
                             {"Dr. Bunsen Honeydew", "humano", 88},
                             {"Beaker", "humano", 30},
                             {"Swedish Chef", "humano", 10}
};

/* Imprime a informação sobre a criatura
. */

void print_criatura(const struct criatura *c) {
  printf("%s, o %s, %d\n", c->nome, c->especie, c->idade);
}

int criatura_cmp(const void *v1, const void *v2) {
  const struct criatura *c1 = v1;
  const struct criatura *c2 = v2;
  return strcmp(c1->nome, c2->nome);
}

int idade_cmp(const void *v1, const void *v2){
  const struct criatura *c1 = v1;
  const struct criatura *c2 = v2;
  int resultado;

  if(c1->idade > c2->idade) resultado = 1;
  else if(c1->idade < c2->idade) resultado = -1;
  else resultado = 0;
  
  return resultado;
}

void encontra_criatura(const char *criatura) {
  struct criatura criatura_procurada;
  struct criatura *resultado;

  criatura_procurada.nome = criatura;

  int numMuppets = sizeof(muppets) / sizeof(struct criatura);

  // Criamos uma criatura  apenas para passar como  argumento na função de
  // comparação
  resultado = bsearch(&criatura_procurada, muppets, numMuppets,
                      sizeof(struct criatura), criatura_cmp);

  if (resultado)
    print_criatura(resultado);
  else
    printf("Nao encontrada %s.\n", criatura);
}

/* Feito pelo professor
struct criatura * encontra_especies(char *especie)
{
  struct criatura criatura_procurada;

  struct criatura *resultado = NULL;

  struct criatura *especies_arr = malloc(sizeof *especies_arr * TAM_INICIAL);

  int numMuppets = sizeof(muppets)/sizeof(struct criatura);
  ///Gera uma copia do array original
  struct criatura *copia_cria = malloc(sizeof *copia_cria * numMuppets);

  memcpy(copia_cria, muppets, numMuppets * sizeof(struct criatura));
  

  //Ordena por especie
  qsort(copia_cria, numMuppets, sizeof(struct criatura), especie_cmp);

  #if DEBUG
  for (int i = 0; i < numMuppets; i++)
    print_criatura(&copia_cria[i]);
  #endif

   criatura_procurada.especie = especie;
   int qtdEspecies =0;
   do{

     resultado = bsearch(&criatura_procurada, copia_cria, numMuppets, sizeof(struct criatura),especie_cmp);

     if(resultado)
     {
         //calcula o index de onde esta o elemento
        int index = (int)((char *)resultado - (char *)copia_cria)/sizeof(struct criatura);

       especies_arr[qtdEspecies] =copia_cria[index];

       //remover o elemento em index
       memmove(copia_cria+index, copia_cria+index+1, (numMuppets-index) *sizeof(struct criatura));
       numMuppets--;
       qtdEspecies++;
     }

      
     
   }while(resultado != NULL);

  free(copia_cria);
  
  if (qtdEspecies == 0)
    printf("Nao encontrado");
  return especies_arr;
}
*/

int main(void) {

  int numMuppets = sizeof(muppets) / sizeof(struct criatura);

  for (int i = 0; i < numMuppets; i++)
    print_criatura(&muppets[i]);

  printf("\n");



  /*3. Ordene as criaturas por nome utilizando a qsort da stdlib.
   */

  qsort(muppets, numMuppets, sizeof(struct criatura), criatura_cmp);

  for (int i = 0; i < numMuppets; i++)
    print_criatura(&muppets[i]);

  printf("\n");  

  /*
  4. Teste a função encontra_criatura procurando na main procurando um muppet
  que existe e outro que não existe.
    */

  encontra_criatura("Kermit");

  printf("\n");

  /*5. Ordene as criaturas por idade utilizando a qsort da stdlib.
   */

  qsort(muppets, numMuppets, sizeof(struct criatura), idade_cmp);

  for (int i = 0; i < numMuppets; i++)
    print_criatura(&muppets[i]);

  printf("\n");  
  
  /*
   6. Imprima a lista de criaturas da mesma espécie.
    */

  return 0;
}