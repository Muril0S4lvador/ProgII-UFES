
#ifndef _DISPATCH_TABLE_
#define _DISPATCH_TABLE_

#include "produto.h"

typedef void (*vetor_produto_fn)(Produto *produtos, int tamanho_vetor);

void dispatch_table_inicializa();

void imprimirProdutos(Produto *produtos, int tamanho_vetor);

void ordenaNome(Produto *produtos, int tamanho_vetor);

void ordenaPontuacao(Produto *produtos, int tamanho_vetor);

void ordenaPreco(Produto *produtos, int tamanho_vetor);

void ordenaLucro(Produto *produtos, int tamanho_vetor);

void imprimirCategorias(Produto *produtos, int tamanho_vetor);

void imprimirRelatorio(Produto *produtos, int tamanho_vetor);

int comparaNomes(const void *v1, const void *v2);

void filtro(char operacao, Produto *produtos, int tamanho_vetor);

#endif