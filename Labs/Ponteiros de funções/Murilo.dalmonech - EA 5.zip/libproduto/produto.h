
#ifndef _PRODUTO_H_
#define _PRODUTO_H_

#include <stdio.h>
#include <string.h>

typedef struct
{
    char nome[64];
    char categoria[64];
    float preco_unitario;
    float custo_unitario;
    int qtd_vendas_ano;
    float pontuacao;
    float lucro_liquido;
    float lucro_bruto;
    float custo_total;
} Produto;

typedef float (*ftpr)(float , float);

void produto_le(FILE *file, Produto *produto);
void produto_imprime(Produto *produto);

float Calcula(ftpr op, float valor1, float valor2);
float custoTotal(float custo, float qtd);
float lucroBruto(float preco, float qtd);
float lucroLiquido(float custoT, float lucroB);

float RetornaCustoTotal(Produto *produto);
float RetornaLucroBruto(Produto *produto);
float RetornaLucroLiquido(Produto *produto);


// TODO: funcoes de comparacao de produtos para utilizacao no qsort
int comparaNomes(const void *v1, const void *v2);
int comparaCategorias(const void *v1, const void *v2);
int comparaPreco(const void *v1, const void *v2);
int comparaPontuacao(const void *v1, const void *v2);
int comparaLucro(const void *v1, const void *v2);

#endif