
#include <stdio.h>
#include <stdlib.h>
#include "produto.h"

void produto_le(FILE *file, Produto *produto)
{
    // TODO
    fscanf(file, "%s", produto->nome);
    fscanf(file, "%s", produto->categoria);
    fscanf(file, "%f", &produto->preco_unitario);
    fscanf(file, "%f", &produto->custo_unitario);
    fscanf(file, "%d", &produto->qtd_vendas_ano);
    fscanf(file, "%f", &produto->pontuacao);

    produto->custo_total = Calcula(custoTotal, produto->custo_unitario, (float) produto->qtd_vendas_ano);
    produto->lucro_bruto = Calcula(lucroBruto, produto->preco_unitario, (float) produto->qtd_vendas_ano);
    produto->lucro_liquido = Calcula(lucroLiquido, produto->custo_total, produto->lucro_bruto);

}

float custoTotal(float custo, float qtd){
    return custo * qtd;
}

float lucroBruto(float preco, float qtd){
    return preco * qtd;
}

float lucroLiquido(float custoT, float lucroB){
    return lucroB - custoT;
}

float Calcula(ftpr calculo, float valor1, float valor2){
    return calculo(valor1, valor2);
}

int comparaNomes(const void *v1, const void *v2){
    const Produto *p1 = v1;
    const Produto *p2 = v2;
    return strcmp(p1->nome, p2->nome);
}

int comparaCategorias(const void *v1, const void *v2){
    const Produto *p1 = v1;
    const Produto *p2 = v2;
    return strcmp(p1->categoria, p2->categoria);
}

int comparaPreco(const void *v1, const void *v2){
    const Produto *p1 = v1;
    const Produto *p2 = v2;
    return (p1->preco_unitario - p2->preco_unitario);
}

int comparaPontuacao(const void *v1, const void *v2){
    const Produto *p1 = v1;
    const Produto *p2 = v2;
    return (p1->pontuacao - p2->pontuacao);
}

int comparaLucro(const void *v1, const void *v2){
    const Produto *p1 = v1;
    const Produto *p2 = v2;
    return (p1->lucro_liquido - p2->lucro_liquido);
}

float RetornaCustoTotal(Produto *produto){
    return produto->custo_total;
}

float RetornaLucroBruto(Produto *produto){
    return produto->lucro_bruto;
}

float RetornaLucroLiquido(Produto *produto){
    return produto->lucro_liquido;
}

void produto_imprime(Produto *produto)
{
    // TODO
    printf("\nNome: %s\n", produto->nome);
    printf("Categoria: %s\n", produto->categoria);
    printf("Preço unitário: %.2f\n", produto->preco_unitario);
    printf("Custo unitário: %.2f\n", produto->custo_unitario);
    printf("Quantidade de Vendas: %d\n", produto->qtd_vendas_ano);
    printf("Pontuaçao: %.2f\n", produto->pontuacao);
    printf("Lucro bruto: %.2f\n", produto->lucro_bruto);
    printf("Lucro liquido: %.2f\n\n", produto->lucro_liquido);
}

