#include <stdio.h>
#include <stdlib.h>
#include "produto.h"
#include "operacoes_produtos.h"

static vetor_produto_fn dispatch_table[256];

// TODO: definicao das funcoes da tabela

void dispatch_table_inicializa()
{
    // apenas para sabermos quais funcoes nao foram definidas ainda
    for (int i = 0; i < 256; i++)
        dispatch_table[i] = NULL;

    // TODO: adicionar funcoes...
    dispatch_table['i'] = imprimirProdutos;
    dispatch_table['n'] = ordenaNome;
    dispatch_table['p'] = ordenaPontuacao;
    dispatch_table['v'] = ordenaPreco;
    dispatch_table['l'] = ordenaLucro;
    dispatch_table['f'] = imprimirCategorias;
    dispatch_table['s'] = imprimirRelatorio;
}

static void dispatch_table_executa(char operacao, Produto *produtos, int tamanho_vetor)
{
    int idx = (int)operacao;

    if (dispatch_table[idx] != NULL)
        dispatch_table[idx](produtos, tamanho_vetor);
    else
        printf(">> ERRO: A funcao '%c' nao foi definida ainda.\n", operacao);
}


void filtro(char operacao, Produto *produtos, int tamanho_vetor)
{
    dispatch_table_executa(operacao, produtos, tamanho_vetor);
}

void imprimirProdutos(Produto *produtos, int tamanho_vetor){
    for(int i = 0; i < tamanho_vetor; i++)
        produto_imprime(produtos+i);
}

void ordenaNome(Produto *produtos, int tamanho_vetor){
    qsort(produtos, tamanho_vetor, sizeof(Produto), comparaNomes);
}

void ordenaPontuacao(Produto *produtos, int tamanho_vetor){
    qsort(produtos, tamanho_vetor, sizeof(Produto), comparaPontuacao);
}

void ordenaPreco(Produto *produtos, int tamanho_vetor){
    qsort(produtos, tamanho_vetor, sizeof(Produto), comparaPreco);
}

void ordenaLucro(Produto *produtos, int tamanho_vetor){
    qsort(produtos, tamanho_vetor, sizeof(Produto), comparaLucro);
}

void imprimirCategorias(Produto *produtos, int tamanho_vetor){
    char categoria[64] = "\0";

    printf("\nEscolha uma categoria: ");
    scanf("%s", &categoria);

    //Encontra a categoria
    // Copia do array original e um array apenas de produtos de uma categoria
    Produto *copia = malloc(tamanho_vetor * sizeof(Produto));
    memcpy(copia, produtos, tamanho_vetor * sizeof(Produto));

    Produto *categoriaptr = malloc(tamanho_vetor * sizeof(Produto));
    Produto *resultado = NULL;

    qsort(copia, tamanho_vetor, sizeof(Produto), comparaCategorias);

    Produto categoriaProcurada;
    // categoriaProcurada.categoria = categoria;
    strcpy(categoriaProcurada.categoria, categoria);
    int qtdCategoria = 0;

    do{
        resultado = bsearch(&categoriaProcurada, copia, tamanho_vetor, sizeof(Produto), comparaCategorias);

        if(resultado){
            int index = (int)((char*)resultado - (char*)copia)/sizeof(Produto);

            categoriaptr[qtdCategoria] = copia[index];

            memmove(copia+index, copia+index+1, (tamanho_vetor-index)*sizeof(Produto));
            tamanho_vetor--;
            qtdCategoria++;
        }
    }while(resultado != NULL);

    free(copia);

    if(qtdCategoria == 0) printf("\nCategoria nao encontrada.\n");
    else{
        printf("\nItens:\n");
        for(int i = 0; i < qtdCategoria; i++){
            printf("%s\n", categoriaptr[i].nome);
        }
    }

    free(categoriaptr);
}

void imprimirRelatorio(Produto *produtos, int tamanho_vetor){
    float somaCusto = 0, somaBruto = 0, somaLiquido = 0;

    for(int i = 0; i < tamanho_vetor; i++){
        somaCusto += RetornaCustoTotal(produtos+i);
        somaBruto += RetornaLucroBruto(produtos+i);
        somaLiquido += RetornaLucroLiquido(produtos+i);
    }
    
    printf("\nCusto total de produção: %.2f\n", somaCusto);
    printf("Lucro bruto: %.2f\n", somaBruto);
    printf("Lucro líquido: %.2f\n",somaLiquido);
}


